My role
=========

This is my study role for 08-ansible-06-module task.


Role Variables
--------------

default:
  file_name
  file_path
  file_content


Example Playbook
----------------

  - name: Test my module
    hosts: localhost
    roles:
      - my_role

License
-------

MIT

Author Information
------------------

ditry86 - Netology student
